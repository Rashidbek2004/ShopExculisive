import "./Deliver.css"
const Deliver = () => {
  return (
    <div>
      <div className="container">
        <div className="deliver">
            <div className="free">
                <img src="/imgs/Services.png" alt="" />
                <h4>FREE AND FAST DELIVERY</h4>
                <h6>Free delivery for all orders over $140</h6>
            </div>  <div className="free">
                <img src="/imgs/Services.png" alt="" />
                <h4>FREE AND FAST DELIVERY</h4>
                <h6>Free delivery for all orders over $140</h6>
            </div>  <div className="free">
                <img src="/imgs/Services.png" alt="" />
                <h4>FREE AND FAST DELIVERY</h4>
                <h6>Free delivery for all orders over $140</h6>
            </div>
        </div>
      </div>
    </div>
  )
}

export default Deliver
